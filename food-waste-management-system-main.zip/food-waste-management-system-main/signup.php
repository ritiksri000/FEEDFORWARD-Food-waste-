<?php
include 'connection.php';
// $connection=mysqli_connect("localhost:3307","root","");
// $db=mysqli_select_db($connection,'demo');
if(isset($_POST['sign']))
{

    $username=$_POST['name'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $gender=$_POST['gender'];

    $pass=password_hash($password,PASSWORD_DEFAULT);
    $sql="select * from login where email='$email'" ;
    $result= mysqli_query($connection, $sql);
    $num=mysqli_num_rows($result);
    if($num==1){

        echo "<h1><center>Account already exists</center></h1>";
    }
    else{
    
    $query="insert into login(name,email,password,gender) values('$username','$email','$pass','$gender')";
    $query_run= mysqli_query($connection, $query);
    if($query_run)
    {
      
       
        header("location:signin.php");
       
    }
    else{
        echo '<script type="text/javascript">alert("data not saved")</script>';
        
    }
}


   
}
?>








<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | FeedForward</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 400px;
            background: #fff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .container:hover {
            transform: scale(1.02);
        }

        .logo {
            text-align: center;
            font-size: 36px;
            margin-bottom: 30px;
        }

        .logo b {
            color: #06C167;
        }

        .input, .password, .radio {
            margin-bottom: 20px;
        }

        .textlabel {
            font-size: 16px;
            margin-bottom: 8px;
            display: block;
        }

        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
            transition: 0.3s;
        }

        input:focus {
            border-color: #06C167;
            outline: none;
            box-shadow: 0 0 5px rgba(6, 193, 103, 0.5);
        }

        .password {
            position: relative;
        }

        .showHidePw {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #999;
        }

        .radio input {
            margin-right: 8px;
        }

        .btn button {
            width: 100%;
            padding: 14px;
            background-color: #06C167;
            color: white;
            font-size: 18px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
        }

        .btn button:hover {
            background-color: #04a557;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .signin-up {
            text-align: center;
            margin-top: 20px;
        }

        .signin-up a {
            color: #06C167;
            text-decoration: none;
            transition: color 0.3s;
        }

        .signin-up a:hover {
            color: #04a557;
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="container">
        <form action="" method="post">
            <p class="logo">FEED<b>FORWARD</b></p>
            <p id="heading">Create your account</p>

            <div class="input">
                <label class="textlabel" for="name">Username</label>
                <input type="text" id="name" name="name" required/>
            </div>

            <div class="input">
                <label class="textlabel" for="email">Email</label>
                <input type="email" id="email" name="email" required/>
            </div>

            <div class="password">
                <label class="textlabel" for="password">Password</label>
                <input type="password" name="password" id="password" required/>
                <i class="uil uil-eye-slash showHidePw" id="showpassword"></i>
            </div>

            <div class="radio">
                <input type="radio" name="gender" id="male" value="male" required/>
                <label for="male">Male</label>
                <input type="radio" name="gender" id="female" value="female">
                <label for="female">Female</label>
            </div>

            <div class="btn">
                <button type="submit" name="sign">Continue</button>
            </div>

            <div class="signin-up">
                <p>Already have an account? <a href="signin.php">Sign in</a></p>
            </div>
        </form>
    </div>

    <script>
        const passwordInput = document.getElementById("password");
        const showPasswordIcon = document.getElementById("showpassword");

        showPasswordIcon.addEventListener("click", () => {
            const isPasswordVisible = passwordInput.type === "password";
            passwordInput.type = isPasswordVisible ? "text" : "password";
            showPasswordIcon.classList.toggle("uil-eye", isPasswordVisible);
            showPasswordIcon.classList.toggle("uil-eye-slash", !isPasswordVisible);
        });
    </script>

</body>
</html>
