<?php
// PHP code remains the same as before
include '../connection.php';
$msg=0;
if(isset($_POST['sign'])) {
    $username=$_POST['username'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $location=$_POST['district'];
    $pass=password_hash($password,PASSWORD_DEFAULT);
    $sql="select * from delivery_persons where email='$email'" ;
    $result= mysqli_query($connection, $sql);
    $num=mysqli_num_rows($result);
    if($num==1){
        echo "<h1><center>Account already exists</center></h1>";
    }
    else {
        $query="insert into delivery_persons(name,email,password,city) values('$username','$email','$pass','$location')";
        $query_run= mysqli_query($connection, $query);
        if($query_run) {
            header("location:delivery.php");
        } else {
            echo '<script type="text/javascript">alert("data not saved")</script>';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .center {
            background-color: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2); /* Soft shadow */
            width: 400px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .center:hover {
            transform: scale(1.03); /* Slight scale on hover */
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        }

        h1 {
            text-align: center;
            color: #333; /* Darker text color for contrast */
            margin-bottom: 20px;
            font-size: 26px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        .txt_field {
            position: relative;
            margin-bottom: 30px;
        }

        .txt_field input, .txt_field select {
            width: 100%;
            padding: 12px;
            background: #f0f0f0;
            border: none;
            border-radius: 10px;
            outline: none;
            transition: all 0.3s ease;
        }

        .txt_field input:hover, .txt_field select:hover {
            background: #e8e8e8; /* Lighter background on hover */
            border: 2px solid #4CAF50; /* Green border on hover */
        }

        .txt_field input:focus, .txt_field select:focus {
            background: #fff;
            border: 2px solid #4CAF50; /* Green border on focus */
        }

        .txt_field label {
            position: absolute;
            top: 50%;
            left: 10px;
            color: #888;
            transform: translateY(-50%);
            transition: all 0.3s ease;
            pointer-events: none;
        }

        .txt_field input:focus + label,
        .txt_field input:not(:placeholder-shown) + label {
            top: -5px;
            left: 10px;
            color: #4CAF50;
            font-size: 12px;
            font-weight: bold;
        }

        select {
            padding: 12px;
            border-radius: 10px;
            background: #f0f0f0;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        select:hover {
            background: #e8e8e8;
            border: 2px solid #4CAF50;
        }

        input[type="submit"] {
            background: linear-gradient(135deg, #4CAF50 0%, #388E3C 100%);
            color: white;
            padding: 12px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background: linear-gradient(135deg, #45a049 0%, #2e7d32 100%);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2); /* Shadow on hover */
        }

        .signup_link {
            margin-top: 20px;
            text-align: center;
        }

        .signup_link a {
            color: #4CAF50;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .signup_link a:hover {
            color: #388E3C; /* Darker green on hover */
        }
    </style>
</head>
<body>
    <div class="center">
        <h1>Register</h1>
        <form method="post" action="">
            <div class="txt_field">
                <input type="text" name="username" required />
                <label>Username</label>
            </div>
            <div class="txt_field">
                <input type="password" name="password" required />
                <label>Password</label>
            </div>
            <div class="txt_field">
                <input type="email" name="email" required />
                <label>Email</label>
            </div>
            <div class="txt_field">
                <select id="district" name="district">
                    <option value="chennai">Chennai</option>
                    <option value="coimbatore">Coimbatore</option>
                    <option value="madurai" selected>Madurai</option>
                </select>
            </div>
            <input type="submit" name="sign" value="Register">
            <div class="signup_link">
                Already a member? <a href="deliverylogin.php">Sign in</a>
            </div>
        </form>
    </div>
</body>
</html>
