<?php
// session_start();
// $connection=mysqli_connect("localhost:3307","root","");
// $db=mysqli_select_db($connection,'demo');
include '../connection.php';
$msg=0;
if(isset($_POST['sign']))
{

    $username=$_POST['username'];
    $email=$_POST['email'];
    $password=$_POST['password'];

    $location=$_POST['district'];
    $address=$_POST['address'];

    $pass=password_hash($password,PASSWORD_DEFAULT);
    $sql="select * from admin where email='$email'" ;
    $result= mysqli_query($connection, $sql);
    $num=mysqli_num_rows($result);
    if($num==1){
        // echo "<h1> already account is created </h1>";
        // echo '<script type="text/javascript">alert("already Account is created")</script>';
        echo "<h1><center>Account already exists</center></h1>";
    }
    else{
    
    $query="insert into admin(name,email,password,location,address) values('$username','$email','$pass','$location','$address')";
    $query_run= mysqli_query($connection, $query);
    if($query_run)
    {
        // $_SESSION['email']=$email;
        // $_SESSION['name']=$row['name'];
        // $_SESSION['gender']=$row['gender'];
       
        header("location:signin.php");
        // echo "<h1><center>Account does not exists </center></h1>";
        //  echo '<script type="text/javascript">alert("Account created successfully")</script>'; -->
    }
    else{
        echo '<script type="text/javascript">alert("data not saved")</script>';
        
    }
}


   
}
?>









<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>

    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f8f9fa 0%, #e0e0e0 100%); /* Soft gradient for background */
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background-color: white; /* Pure white background for the form container */
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            width: 400px;
            position: relative;
            transition: transform 0.2s; /* Smooth scaling on hover */
        }

        .container:hover {
            transform: scale(1.02); /* Slight scale on hover */
        }

        .title {
            font-size: 28px;
            font-weight: bold;
            color: #28a745; /* Green color for the title */
            text-align: center;
            margin-bottom: 30px;
            text-transform: uppercase; /* Uppercase for a modern touch */
        }

        .input-group {
            position: relative;
            margin-bottom: 20px;
        }

        label {
            font-size: 14px;
            color: #555; /* Darker gray for better readability */
            display: block;
            margin-bottom: 8px;
        }

        input[type="text"], input[type="email"], input[type="password"], textarea, select {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ced4da; /* Light gray border */
            font-size: 14px;
            transition: all 0.3s ease;
        }

        input:focus, textarea:focus, select:focus {
            border-color: #28a745; /* Green border on focus */
            outline: none;
            box-shadow: 0 0 5px rgba(40, 167, 69, 0.5); /* Green glow on focus */
        }

        input:hover, textarea:hover, select:hover {
            border-color: #28a745; /* Green border on hover */
        }

        .password {
            position: relative;
        }

        .showHidePw {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #999;
            transition: color 0.3s ease; /* Smooth color change */
        }

        .showHidePw:hover {
            color: #28a745; /* Change color on hover */
        }

        button[type="submit"] {
            width: 100%;
            padding: 12px;
            background-color: #28a745; /* Green background */
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.2s ease; /* Added box-shadow transition */
        }

        button[type="submit"]:hover {
            background-color: #218838; /* Darker green on hover */
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Shadow on hover */
        }

        .login-signup {
            text-align: center;
            margin-top: 20px;
        }

        .login-signup a {
            color: #28a745; /* Green link color */
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        .login-signup a:hover {
            color: #218838; /* Darker green on hover */
        }
    </style>
</head>
<body>

    <div class="container">
        <form action="" method="post" id="form">
            <span class="title">Register</span>
            
            <div class="input-group">
                <label for="username">Name</label>
                <input type="text" id="username" name="username" required/>
            </div>

            <div class="input-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required/>
            </div>

            <div class="input-group password">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" required/>
                <i class="uil uil-eye-slash showHidePw" id="showpassword"></i>
            </div>

            <div class="input-group">
                <label for="address">Address</label>
                <textarea id="address" name="address" required></textarea>
            </div>

            <div class="input-group">
                <label for="district">Location:</label>
                <select id="district" name="district" required>
                    <option value="chennai">Chennai</option>
                    <option value="kancheepuram">Kancheepuram</option>
                    <option value="madurai" selected>Madurai</option>
                    <!-- Add other district options as needed -->
                </select>
            </div>

            <button type="submit" name="sign">Register</button>

            <div class="login-signup">
                <span class="text">Already a member? <a href="signin.php">Login Now</a></span>
            </div>
        </form>
    </div>

    <script>
        const passwordInput = document.getElementById("password");
        const showPasswordIcon = document.getElementById("showpassword");

        showPasswordIcon.addEventListener("click", () => {
            const isPasswordVisible = passwordInput.type === "password";
            passwordInput.type = isPasswordVisible ? "text" : "password";
            showPasswordIcon.classList.toggle("uil-eye", isPasswordVisible);
            showPasswordIcon.classList.toggle("uil-eye-slash", !isPasswordVisible);
        });
    </script>

</body>
</html>
